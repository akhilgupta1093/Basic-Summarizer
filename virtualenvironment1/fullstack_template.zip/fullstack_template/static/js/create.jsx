import React from "react";
import InputText from "./InputText";
//import createSummary from "./Action";

export default class Create extends React.Component {
	
//	handleSubmit(data) {
//		createSummary(data);
//	}

	render() {
		return (
			<div>
				<InputText />
			</div>
		);
	}
}






